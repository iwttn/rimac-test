/**
 * @description Tiene el equivalente de los id de los films(swapi) a los imdbid(imdb)
 */
export const imdbFilmIdMap = {
    '1': 'tt0120915',
    '2': 'tt0121765',
    '3': 'tt0121766',
    '4': 'tt0076759',
    '5': 'tt0080684',
    '6': 'tt0086190'
}