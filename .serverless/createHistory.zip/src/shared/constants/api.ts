export const API_SWAPI_URL = 'https://swapi.dev/api';
export const API_IMDB_URL = 'https://imdb236.p.rapidapi.com/imdb';