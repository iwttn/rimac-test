export type PaginateParams = {
    page: number;
    totalPerPage: number;
}
