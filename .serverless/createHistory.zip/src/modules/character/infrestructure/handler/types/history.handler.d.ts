export type HistoryEventDetail = {
    typeHistory: 'unique' | 'many';
    payload: string;
}